const express = require('express');
const ExcelJS = require('exceljs');
const pool = require('../db/pool');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// GET /api/forms/:formId/export — Export submissions as Excel
router.get('/:formId/export', authenticate, requireAdmin, async (req, res, next) => {
    try {
        // Get form
        const formResult = await pool.query('SELECT * FROM forms WHERE id = $1', [req.params.formId]);
        if (formResult.rows.length === 0) return res.status(404).json({ error: 'Form not found' });
        const form = formResult.rows[0];

        // Get latest version
        const versionResult = await pool.query(
            'SELECT * FROM form_versions WHERE form_id = $1 ORDER BY version_number DESC LIMIT 1',
            [form.id]
        );
        if (versionResult.rows.length === 0) {
            return res.status(400).json({ error: 'Form has no versions' });
        }
        const version = versionResult.rows[0];

        // Get fields
        const fieldsResult = await pool.query(
            'SELECT * FROM form_fields WHERE form_version_id = $1 ORDER BY field_order ASC',
            [version.id]
        );
        const fields = fieldsResult.rows;

        // Get submissions
        const subsResult = await pool.query(`
      SELECT s.*, u.username as submitted_by_name
      FROM submissions s
      LEFT JOIN users u ON s.submitted_by = u.id
      WHERE s.form_version_id = $1
      ORDER BY s.submitted_at ASC
    `, [version.id]);

        // Get all values
        const subIds = subsResult.rows.map((s) => s.id);
        let allValues = [];
        if (subIds.length > 0) {
            const valuesResult = await pool.query(
                'SELECT * FROM submission_values WHERE submission_id = ANY($1)',
                [subIds]
            );
            allValues = valuesResult.rows;
        }

        // Build workbook
        const workbook = new ExcelJS.Workbook();
        workbook.creator = 'Form Dashboard';
        workbook.created = new Date();

        const sheet = workbook.addWorksheet(form.name.substring(0, 31));

        // Header columns
        const columns = [
            { header: 'S.No', key: 'sno', width: 8 },
        ];

        for (const field of fields) {
            columns.push({
                header: field.label,
                key: `field_${field.id}`,
                width: Math.max(field.label.length + 5, 15),
            });
        }

        sheet.columns = columns;

        // Style header row
        const headerRow = sheet.getRow(1);
        headerRow.font = { bold: true };
        headerRow.alignment = { vertical: 'middle', horizontal: 'center' };

        // Data rows
        subsResult.rows.forEach((sub, index) => {
            const row = {
                sno: index + 1,
            };

            for (const field of fields) {
                const val = allValues.find((v) => v.submission_id === sub.id && v.field_id === field.id);
                row[`field_${field.id}`] = val ? val.value : '';
            }

            sheet.addRow(row);
        });

        // Auto-filter
        sheet.autoFilter = {
            from: { row: 1, column: 1 },
            to: { row: 1, column: columns.length },
        };

        // Set response headers
        const filename = `${form.name.replace(/[^a-zA-Z0-9_-]/g, '_')}_export.xlsx`;
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

        await workbook.xlsx.write(res);
        res.end();
    } catch (err) {
        next(err);
    }
});

module.exports = router;
