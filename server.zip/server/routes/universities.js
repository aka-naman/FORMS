const express = require('express');
const Joi = require('joi');
const pool = require('../db/pool');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();

const universitySchema = Joi.object({
    name: Joi.string().min(1).max(500).required(),
    state: Joi.string().min(1).max(200).required(),
    district: Joi.string().min(1).max(200).required(),
});

// GET /api/universities — List universities (with optional search)
router.get('/', authenticate, requireAdmin, async (req, res, next) => {
    try {
        const q = (req.query.q || '').trim();
        const page = Math.max(1, parseInt(req.query.page) || 1);
        const limit = 25;
        const offset = (page - 1) * limit;

        let query, countQuery, params, countParams;

        if (q.length >= 2) {
            query = `SELECT * FROM universities WHERE name ILIKE $1 ORDER BY name LIMIT $2 OFFSET $3`;
            countQuery = `SELECT COUNT(*) FROM universities WHERE name ILIKE $1`;
            params = ['%' + q + '%', limit, offset];
            countParams = ['%' + q + '%'];
        } else {
            query = `SELECT * FROM universities ORDER BY name LIMIT $1 OFFSET $2`;
            countQuery = `SELECT COUNT(*) FROM universities`;
            params = [limit, offset];
            countParams = [];
        }

        const [result, countResult] = await Promise.all([
            pool.query(query, params),
            pool.query(countQuery, countParams),
        ]);

        res.json({
            universities: result.rows,
            total: parseInt(countResult.rows[0].count),
            page,
            pages: Math.ceil(parseInt(countResult.rows[0].count) / limit),
        });
    } catch (err) {
        next(err);
    }
});

// POST /api/universities — Add new university (admin)
router.post('/', authenticate, requireAdmin, async (req, res, next) => {
    try {
        const { error, value } = universitySchema.validate(req.body);
        if (error) return res.status(400).json({ error: error.details[0].message });

        // Check duplicate
        const existing = await pool.query(
            'SELECT id FROM universities WHERE LOWER(name) = LOWER($1)',
            [value.name.trim()]
        );
        if (existing.rows.length > 0) {
            return res.status(409).json({ error: 'University with this name already exists' });
        }

        const result = await pool.query(
            'INSERT INTO universities (name, state, district) VALUES ($1, $2, $3) RETURNING *',
            [value.name.trim(), value.state.trim(), value.district.trim()]
        );

        res.status(201).json({ university: result.rows[0] });
    } catch (err) {
        next(err);
    }
});

// DELETE /api/universities/:id — Delete university (admin)
router.delete('/:id', authenticate, requireAdmin, async (req, res, next) => {
    try {
        const result = await pool.query('DELETE FROM universities WHERE id = $1 RETURNING id', [req.params.id]);
        if (result.rows.length === 0) return res.status(404).json({ error: 'University not found' });
        res.json({ message: 'University deleted' });
    } catch (err) {
        next(err);
    }
});

module.exports = router;
