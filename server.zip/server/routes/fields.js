const express = require('express');
const Joi = require('joi');
const pool = require('../db/pool');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router({ mergeParams: true });

const fieldSchema = Joi.object({
    label: Joi.string().min(1).max(200).required(),
    type: Joi.string().valid('text', 'textarea', 'dropdown', 'pincode', 'college_autocomplete', 'university_autocomplete').required(),
    options_json: Joi.object().default({}),
    field_order: Joi.number().integer().min(0).required(),
    required: Joi.boolean().default(false),
});

const fieldsArraySchema = Joi.object({
    fields: Joi.array().items(fieldSchema).min(0).required(),
});

// GET /api/forms/:formId/versions/:versionId/fields
router.get('/:formId/versions/:versionId/fields', authenticate, async (req, res, next) => {
    try {
        const result = await pool.query(
            'SELECT * FROM form_fields WHERE form_version_id = $1 ORDER BY field_order ASC',
            [req.params.versionId]
        );
        res.json({ fields: result.rows });
    } catch (err) {
        next(err);
    }
});

// PUT /api/forms/:formId/versions/:versionId/fields — Bulk save (replace all)
router.put('/:formId/versions/:versionId/fields', authenticate, requireAdmin, async (req, res, next) => {
    try {
        // Check if form is locked
        const formResult = await pool.query('SELECT is_locked FROM forms WHERE id = $1', [req.params.formId]);
        if (formResult.rows.length === 0) return res.status(404).json({ error: 'Form not found' });
        if (formResult.rows[0].is_locked) return res.status(400).json({ error: 'Form is locked. Create a new version to modify fields.' });

        const { error, value } = fieldsArraySchema.validate(req.body);
        if (error) return res.status(400).json({ error: error.details[0].message });

        const client = await pool.connect();
        try {
            await client.query('BEGIN');

            // Delete existing fields for this version
            await client.query('DELETE FROM form_fields WHERE form_version_id = $1', [req.params.versionId]);

            // Insert new fields
            const insertedFields = [];
            for (const field of value.fields) {
                const result = await client.query(
                    'INSERT INTO form_fields (form_version_id, label, type, options_json, field_order, required) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
                    [req.params.versionId, field.label, field.type, JSON.stringify(field.options_json), field.field_order, field.required]
                );
                insertedFields.push(result.rows[0]);
            }

            await client.query('COMMIT');
            res.json({ fields: insertedFields });
        } catch (err) {
            await client.query('ROLLBACK');
            throw err;
        } finally {
            client.release();
        }
    } catch (err) {
        next(err);
    }
});

module.exports = router;
