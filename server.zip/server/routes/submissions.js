const express = require('express');
const Joi = require('joi');
const pool = require('../db/pool');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();

const submitSchema = Joi.object({
    values: Joi.object().pattern(
        Joi.number().integer(),
        Joi.string().allow('').max(5000)
    ).required(),
});

// POST /api/forms/:formId/submit — Submit form
router.post('/:formId/submit', authenticate, async (req, res, next) => {
    try {
        const { error, value } = submitSchema.validate(req.body);
        if (error) return res.status(400).json({ error: error.details[0].message });

        // Get latest version
        const versionResult = await pool.query(
            'SELECT * FROM form_versions WHERE form_id = $1 ORDER BY version_number DESC LIMIT 1',
            [req.params.formId]
        );
        if (versionResult.rows.length === 0) {
            return res.status(404).json({ error: 'Form has no versions' });
        }
        const version = versionResult.rows[0];

        // Get fields to validate against
        const fieldsResult = await pool.query(
            'SELECT * FROM form_fields WHERE form_version_id = $1 ORDER BY field_order',
            [version.id]
        );
        const fields = fieldsResult.rows;

        // Validate required fields
        for (const field of fields) {
            if (field.required && (!value.values[field.id] || value.values[field.id].trim() === '')) {
                return res.status(400).json({ error: `Field "${field.label}" is required` });
            }
        }

        const client = await pool.connect();
        try {
            await client.query('BEGIN');

            // Auto-lock form after first submission
            await client.query('UPDATE forms SET is_locked = true WHERE id = $1 AND is_locked = false', [req.params.formId]);

            // Insert submission
            const subResult = await client.query(
                'INSERT INTO submissions (form_version_id, submitted_by) VALUES ($1, $2) RETURNING *',
                [version.id, req.user.id]
            );
            const submission = subResult.rows[0];

            // Insert submission values
            const fieldIds = fields.map((f) => f.id);
            for (const [fieldId, val] of Object.entries(value.values)) {
                const fId = parseInt(fieldId);
                if (fieldIds.includes(fId)) {
                    await client.query(
                        'INSERT INTO submission_values (submission_id, field_id, value) VALUES ($1, $2, $3)',
                        [submission.id, fId, val]
                    );
                }
            }

            await client.query('COMMIT');
            res.status(201).json({ submission });
        } catch (err) {
            await client.query('ROLLBACK');
            throw err;
        } finally {
            client.release();
        }
    } catch (err) {
        next(err);
    }
});

// GET /api/forms/:formId/submissions — List submissions (admin)
router.get('/:formId/submissions', authenticate, requireAdmin, async (req, res, next) => {
    try {
        // Get latest version
        const versionResult = await pool.query(
            'SELECT * FROM form_versions WHERE form_id = $1 ORDER BY version_number DESC LIMIT 1',
            [req.params.formId]
        );
        if (versionResult.rows.length === 0) {
            return res.json({ submissions: [], fields: [] });
        }
        const version = versionResult.rows[0];

        // Get fields
        const fieldsResult = await pool.query(
            'SELECT * FROM form_fields WHERE form_version_id = $1 ORDER BY field_order',
            [version.id]
        );

        // Get submissions with values
        const subsResult = await pool.query(`
      SELECT s.*, u.username as submitted_by_name
      FROM submissions s
      LEFT JOIN users u ON s.submitted_by = u.id
      WHERE s.form_version_id = $1
      ORDER BY s.submitted_at DESC
    `, [version.id]);

        // Get all values for these submissions
        const subIds = subsResult.rows.map((s) => s.id);
        let allValues = [];
        if (subIds.length > 0) {
            const valuesResult = await pool.query(
                'SELECT * FROM submission_values WHERE submission_id = ANY($1)',
                [subIds]
            );
            allValues = valuesResult.rows;
        }

        // Attach values to submissions
        const submissions = subsResult.rows.map((sub) => ({
            ...sub,
            values: allValues.filter((v) => v.submission_id === sub.id),
        }));

        res.json({ submissions, fields: fieldsResult.rows });
    } catch (err) {
        next(err);
    }
});

module.exports = router;
