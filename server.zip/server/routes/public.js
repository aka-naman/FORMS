const express = require('express');
const Joi = require('joi');
const pool = require('../db/pool');

const router = express.Router();

// GET /api/public/forms/:formId — Get form schema (no auth)
router.get('/forms/:formId', async (req, res, next) => {
    try {
        const formResult = await pool.query('SELECT * FROM forms WHERE id = $1', [req.params.formId]);
        if (formResult.rows.length === 0) return res.status(404).json({ error: 'Form not found' });

        const form = formResult.rows[0];

        const versionResult = await pool.query(
            'SELECT * FROM form_versions WHERE form_id = $1 ORDER BY version_number DESC LIMIT 1',
            [form.id]
        );

        let version = null;
        let fields = [];

        if (versionResult.rows.length > 0) {
            version = versionResult.rows[0];
            const fieldsResult = await pool.query(
                'SELECT * FROM form_fields WHERE form_version_id = $1 ORDER BY field_order ASC',
                [version.id]
            );
            fields = fieldsResult.rows;
        }

        res.json({ form, version, fields });
    } catch (err) {
        next(err);
    }
});

// POST /api/public/forms/:formId/submit — Submit form (no auth)
const submitSchema = Joi.object({
    values: Joi.object().pattern(
        Joi.number().integer(),
        Joi.string().allow('').max(5000)
    ).required(),
    respondent_name: Joi.string().allow('').max(200).optional(),
});

router.post('/forms/:formId/submit', async (req, res, next) => {
    try {
        const { error, value } = submitSchema.validate(req.body);
        if (error) return res.status(400).json({ error: error.details[0].message });

        // Get latest version
        const versionResult = await pool.query(
            'SELECT * FROM form_versions WHERE form_id = $1 ORDER BY version_number DESC LIMIT 1',
            [req.params.formId]
        );
        if (versionResult.rows.length === 0) {
            return res.status(404).json({ error: 'Form has no versions' });
        }
        const version = versionResult.rows[0];

        // Get fields
        const fieldsResult = await pool.query(
            'SELECT * FROM form_fields WHERE form_version_id = $1 ORDER BY field_order',
            [version.id]
        );
        const fields = fieldsResult.rows;

        // Validate required fields
        for (const field of fields) {
            if (field.required && (!value.values[field.id] || value.values[field.id].trim() === '')) {
                return res.status(400).json({ error: `Field "${field.label}" is required` });
            }
        }

        const client = await pool.connect();
        try {
            await client.query('BEGIN');

            // Auto-lock form after first submission
            await client.query('UPDATE forms SET is_locked = true WHERE id = $1 AND is_locked = false', [req.params.formId]);

            // Insert submission (no submitted_by — it's public)
            const subResult = await client.query(
                'INSERT INTO submissions (form_version_id) VALUES ($1) RETURNING *',
                [version.id]
            );
            const submission = subResult.rows[0];

            // Insert submission values
            const fieldIds = fields.map((f) => f.id);
            for (const [fieldId, val] of Object.entries(value.values)) {
                const fId = parseInt(fieldId);
                if (fieldIds.includes(fId)) {
                    await client.query(
                        'INSERT INTO submission_values (submission_id, field_id, value) VALUES ($1, $2, $3)',
                        [submission.id, fId, val]
                    );
                }
            }

            await client.query('COMMIT');
            res.status(201).json({ submission });
        } catch (err) {
            await client.query('ROLLBACK');
            throw err;
        } finally {
            client.release();
        }
    } catch (err) {
        next(err);
    }
});

// GET /api/public/autocomplete/pincode?q= — Pincode search (no auth)
router.get('/autocomplete/pincode', async (req, res, next) => {
    try {
        const q = (req.query.q || '').trim();
        if (!q || q.length < 1) return res.json({ results: [] });

        // Search by pincode prefix, district name, or state name
        const result = await pool.query(
            `SELECT pincode, district, state FROM pincodes 
       WHERE pincode LIKE $1 
          OR LOWER(district) LIKE LOWER($2) 
          OR LOWER(state) LIKE LOWER($2)
       ORDER BY 
         CASE WHEN pincode LIKE $1 THEN 0 ELSE 1 END,
         pincode
       LIMIT 10`,
            [q + '%', '%' + q + '%']
        );

        res.json({ results: result.rows });
    } catch (err) {
        next(err);
    }
});

// GET /api/public/autocomplete/college?q= — College search (no auth)
router.get('/autocomplete/college', async (req, res, next) => {
    try {
        const q = (req.query.q || '').trim();
        if (q.length < 2) return res.json({ results: [] });

        // Use ILIKE for substring matching (more intuitive than trigram for short queries)
        const result = await pool.query(
            `SELECT id, name, state, district
       FROM colleges
       WHERE LOWER(name) LIKE LOWER($1)
          OR LOWER(district) LIKE LOWER($1)
          OR LOWER(state) LIKE LOWER($1)
       ORDER BY 
         CASE WHEN LOWER(name) LIKE LOWER($2) THEN 0 ELSE 1 END,
         name
       LIMIT 10`,
            ['%' + q + '%', q + '%']
        );

        res.json({ results: result.rows });
    } catch (err) {
        next(err);
    }
});

// GET /api/public/autocomplete/university?q= — University search (no auth)
router.get('/autocomplete/university', async (req, res, next) => {
    try {
        const q = (req.query.q || '').trim();
        if (q.length < 2) return res.json({ results: [] });

        const result = await pool.query(
            `SELECT id, name, state, district
       FROM universities
       WHERE name ILIKE $1
       ORDER BY 
         CASE WHEN name ILIKE $2 THEN 0 ELSE 1 END,
         name
       LIMIT 10`,
            ['%' + q + '%', q + '%']
        );

        res.json({ results: result.rows });
    } catch (err) {
        next(err);
    }
});

module.exports = router;
