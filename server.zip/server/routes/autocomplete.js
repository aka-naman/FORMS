const express = require('express');
const pool = require('../db/pool');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

// GET /api/autocomplete/pincode?q=110001
router.get('/pincode', authenticate, async (req, res, next) => {
    try {
        const q = (req.query.q || '').trim();
        if (!q || q.length < 1) return res.json({ results: [] });

        const result = await pool.query(
            'SELECT pincode, district, state FROM pincodes WHERE pincode LIKE $1 LIMIT 10',
            [q + '%']
        );

        res.json({ results: result.rows });
    } catch (err) {
        next(err);
    }
});

// GET /api/autocomplete/college?q=indian
router.get('/college', authenticate, async (req, res, next) => {
    try {
        const q = (req.query.q || '').trim();
        if (q.length < 2) return res.json({ results: [] });

        const result = await pool.query(
            `SELECT id, name, state, district, similarity(name, $1) as sim
       FROM colleges
       WHERE name % $1 OR name ILIKE $2
       ORDER BY sim DESC
       LIMIT 10`,
            [q, `%${q}%`]
        );

        res.json({ results: result.rows });
    } catch (err) {
        next(err);
    }
});

module.exports = router;
