const express = require('express');
const Joi = require('joi');
const pool = require('../db/pool');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();

const formSchema = Joi.object({
    name: Joi.string().min(1).max(200).required(),
});

// GET /api/forms — List all forms
router.get('/', authenticate, async (req, res, next) => {
    try {
        const result = await pool.query(`
      SELECT f.*, 
        (SELECT COUNT(*) FROM form_versions fv WHERE fv.form_id = f.id) as version_count,
        (SELECT MAX(fv.id) FROM form_versions fv WHERE fv.form_id = f.id) as latest_version_id,
        (SELECT COUNT(*) FROM submissions s 
         JOIN form_versions fv ON s.form_version_id = fv.id 
         WHERE fv.form_id = f.id) as submission_count
      FROM forms f
      ORDER BY f.created_at DESC
    `);
        res.json({ forms: result.rows });
    } catch (err) {
        next(err);
    }
});

// GET /api/forms/:id — Get single form with latest version and fields
router.get('/:id', authenticate, async (req, res, next) => {
    try {
        const formResult = await pool.query('SELECT * FROM forms WHERE id = $1', [req.params.id]);
        if (formResult.rows.length === 0) return res.status(404).json({ error: 'Form not found' });

        const form = formResult.rows[0];

        // Get latest version
        const versionResult = await pool.query(
            'SELECT * FROM form_versions WHERE form_id = $1 ORDER BY version_number DESC LIMIT 1',
            [form.id]
        );

        let version = null;
        let fields = [];

        if (versionResult.rows.length > 0) {
            version = versionResult.rows[0];
            const fieldsResult = await pool.query(
                'SELECT * FROM form_fields WHERE form_version_id = $1 ORDER BY field_order ASC',
                [version.id]
            );
            fields = fieldsResult.rows;
        }

        res.json({ form, version, fields });
    } catch (err) {
        next(err);
    }
});

// POST /api/forms — Create new form (admin)
router.post('/', authenticate, requireAdmin, async (req, res, next) => {
    try {
        const { error, value } = formSchema.validate(req.body);
        if (error) return res.status(400).json({ error: error.details[0].message });

        const client = await pool.connect();
        try {
            await client.query('BEGIN');

            const formResult = await client.query(
                'INSERT INTO forms (name, created_by) VALUES ($1, $2) RETURNING *',
                [value.name, req.user.id]
            );
            const form = formResult.rows[0];

            // Create initial version
            const versionResult = await client.query(
                'INSERT INTO form_versions (form_id, version_number) VALUES ($1, 1) RETURNING *',
                [form.id]
            );

            await client.query('COMMIT');
            res.status(201).json({ form, version: versionResult.rows[0] });
        } catch (err) {
            await client.query('ROLLBACK');
            throw err;
        } finally {
            client.release();
        }
    } catch (err) {
        next(err);
    }
});

// PUT /api/forms/:id — Rename form (admin)
router.put('/:id', authenticate, requireAdmin, async (req, res, next) => {
    try {
        const { error, value } = formSchema.validate(req.body);
        if (error) return res.status(400).json({ error: error.details[0].message });

        const result = await pool.query(
            'UPDATE forms SET name = $1 WHERE id = $2 RETURNING *',
            [value.name, req.params.id]
        );

        if (result.rows.length === 0) return res.status(404).json({ error: 'Form not found' });
        res.json({ form: result.rows[0] });
    } catch (err) {
        next(err);
    }
});

// DELETE /api/forms/:id — Delete form (admin)
router.delete('/:id', authenticate, requireAdmin, async (req, res, next) => {
    try {
        const result = await pool.query('DELETE FROM forms WHERE id = $1 RETURNING id', [req.params.id]);
        if (result.rows.length === 0) return res.status(404).json({ error: 'Form not found' });
        res.json({ message: 'Form deleted', id: parseInt(req.params.id) });
    } catch (err) {
        next(err);
    }
});

// POST /api/forms/:id/duplicate — Duplicate form (admin)
router.post('/:id/duplicate', authenticate, requireAdmin, async (req, res, next) => {
    try {
        const client = await pool.connect();
        try {
            await client.query('BEGIN');

            // Get original form
            const formResult = await client.query('SELECT * FROM forms WHERE id = $1', [req.params.id]);
            if (formResult.rows.length === 0) {
                await client.query('ROLLBACK');
                return res.status(404).json({ error: 'Form not found' });
            }
            const original = formResult.rows[0];

            // Create new form
            const newFormResult = await client.query(
                'INSERT INTO forms (name, created_by) VALUES ($1, $2) RETURNING *',
                [`Copy of ${original.name}`, req.user.id]
            );
            const newForm = newFormResult.rows[0];

            // Get latest version of original
            const versionResult = await client.query(
                'SELECT * FROM form_versions WHERE form_id = $1 ORDER BY version_number DESC LIMIT 1',
                [original.id]
            );

            if (versionResult.rows.length > 0) {
                const origVersion = versionResult.rows[0];

                // Create new version
                const newVersionResult = await client.query(
                    'INSERT INTO form_versions (form_id, version_number) VALUES ($1, 1) RETURNING *',
                    [newForm.id]
                );
                const newVersion = newVersionResult.rows[0];

                // Copy fields
                const fieldsResult = await client.query(
                    'SELECT * FROM form_fields WHERE form_version_id = $1 ORDER BY field_order',
                    [origVersion.id]
                );

                for (const field of fieldsResult.rows) {
                    await client.query(
                        'INSERT INTO form_fields (form_version_id, label, type, options_json, field_order, required) VALUES ($1, $2, $3, $4, $5, $6)',
                        [newVersion.id, field.label, field.type, field.options_json, field.field_order, field.required]
                    );
                }
            }

            await client.query('COMMIT');
            res.status(201).json({ form: newForm });
        } catch (err) {
            await client.query('ROLLBACK');
            throw err;
        } finally {
            client.release();
        }
    } catch (err) {
        next(err);
    }
});

// POST /api/forms/:id/lock — Lock form (admin)
router.post('/:id/lock', authenticate, requireAdmin, async (req, res, next) => {
    try {
        const result = await pool.query(
            'UPDATE forms SET is_locked = true WHERE id = $1 RETURNING *',
            [req.params.id]
        );
        if (result.rows.length === 0) return res.status(404).json({ error: 'Form not found' });
        res.json({ form: result.rows[0] });
    } catch (err) {
        next(err);
    }
});

module.exports = router;
