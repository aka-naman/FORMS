require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');

const authRoutes = require('./routes/auth');
const formRoutes = require('./routes/forms');
const fieldRoutes = require('./routes/fields');
const submissionRoutes = require('./routes/submissions');
const autocompleteRoutes = require('./routes/autocomplete');
const exportRoutes = require('./routes/export');
const publicRoutes = require('./routes/public');
const universityRoutes = require('./routes/universities');

const app = express();
const PORT = parseInt(process.env.PORT, 10) || 5000;

// Middleware
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(morgan('dev'));

// Public API Routes (no auth required)
app.use('/api/public', publicRoutes);

// Authenticated API Routes
app.use('/api/auth', authRoutes);
app.use('/api/forms', formRoutes);
app.use('/api/forms', fieldRoutes);
app.use('/api/forms', submissionRoutes);
app.use('/api/autocomplete', autocompleteRoutes);
app.use('/api/forms', exportRoutes);
app.use('/api/universities', universityRoutes);

// Serve frontend in production
const clientBuildPath = path.join(__dirname, '..', 'client', 'dist');
app.use(express.static(clientBuildPath));
app.get('*', (req, res) => {
    if (!req.path.startsWith('/api')) {
        res.sendFile(path.join(clientBuildPath, 'index.html'));
    }
});

// Error handler
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Server running on http://0.0.0.0:${PORT}`);
});

module.exports = app;
