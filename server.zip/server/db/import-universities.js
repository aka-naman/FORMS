/**
 * Import universities from Excel file into PostgreSQL.
 * 
 * Usage: node db/import-universities.js [path-to-xlsx]
 * Default path: ../Final_list_Collges.xlsx
 * 
 * Excel format: Column A = University Name, Column B = State, Column C = District
 */

const path = require('path');
const ExcelJS = require('exceljs');
const pool = require('./pool');

// Helper: proper case conversion
function properCase(str) {
    if (!str) return '';
    return str.trim().replace(/\w\S*/g, (txt) =>
        txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
    );
}

async function importUniversities() {
    const xlsxPath = process.argv[2] || path.join(__dirname, '..', '..', 'Final_list_Collges.xlsx');

    console.log(`📂 Reading Excel file: ${xlsxPath}`);

    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.readFile(xlsxPath);
    const worksheet = workbook.worksheets[0];

    if (!worksheet) {
        console.error('❌ No worksheet found in the Excel file');
        process.exit(1);
    }

    const rows = [];
    const seen = new Set();

    worksheet.eachRow((row, rowNumber) => {
        if (rowNumber === 1) return; // skip header

        const name = (row.getCell(1).text || '').trim();
        const state = (row.getCell(2).text || '').trim();
        const district = (row.getCell(3).text || '').trim();

        if (!name) return; // skip empty rows

        // Normalize text
        const normalizedName = properCase(name);
        const normalizedState = properCase(state);
        const normalizedDistrict = properCase(district);

        // Deduplicate by lowercase name
        const key = normalizedName.toLowerCase();
        if (seen.has(key)) return;
        seen.add(key);

        rows.push({
            name: normalizedName,
            state: normalizedState,
            district: normalizedDistrict,
        });
    });

    console.log(`📊 Found ${rows.length} unique universities (after dedup)`);

    const client = await pool.connect();
    try {
        await client.query('BEGIN');

        // Create universities table if not exists
        await client.query(`
            CREATE EXTENSION IF NOT EXISTS pg_trgm;
            
            CREATE TABLE IF NOT EXISTS universities (
                id SERIAL PRIMARY KEY,
                name TEXT NOT NULL,
                state TEXT NOT NULL,
                district TEXT NOT NULL
            );
        `);

        // Clear existing data
        await client.query('TRUNCATE TABLE universities RESTART IDENTITY CASCADE');

        // Batch insert (100 at a time)
        const batchSize = 100;
        let inserted = 0;

        for (let i = 0; i < rows.length; i += batchSize) {
            const batch = rows.slice(i, i + batchSize);
            const values = [];
            const placeholders = [];

            batch.forEach((row, j) => {
                const base = j * 3;
                placeholders.push(`($${base + 1}, $${base + 2}, $${base + 3})`);
                values.push(row.name, row.state, row.district);
            });

            await client.query(
                `INSERT INTO universities (name, state, district) VALUES ${placeholders.join(', ')}`,
                values
            );
            inserted += batch.length;
            process.stdout.write(`\r  ⏳ Inserted ${inserted}/${rows.length} universities...`);
        }

        // Create trigram index for fast search
        await client.query('DROP INDEX IF EXISTS idx_universities_name_trgm');
        await client.query('CREATE INDEX idx_universities_name_trgm ON universities USING gin (name gin_trgm_ops)');
        await client.query('DROP INDEX IF EXISTS idx_universities_name_lower');
        await client.query('CREATE INDEX idx_universities_name_lower ON universities USING gin (LOWER(name) gin_trgm_ops)');

        await client.query('COMMIT');
        console.log(`\n✅ Successfully imported ${inserted} universities`);
        console.log(`✅ Trigram index created for fast search`);
    } catch (err) {
        await client.query('ROLLBACK');
        console.error('❌ Import failed:', err.message);
        throw err;
    } finally {
        client.release();
        await pool.end();
    }
}

importUniversities().catch((err) => {
    console.error(err);
    process.exit(1);
});
