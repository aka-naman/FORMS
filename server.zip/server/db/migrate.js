const pool = require('./pool');

async function migrate() {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');

        // Enable pg_trgm extension for fuzzy search
        await client.query('CREATE EXTENSION IF NOT EXISTS pg_trgm');

        // Users table (not in original spec but needed for auth)
        await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username VARCHAR(100) UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role VARCHAR(20) NOT NULL DEFAULT 'user',
        created_at TIMESTAMP DEFAULT NOW()
      )
    `);

        // Forms table
        await client.query(`
      CREATE TABLE IF NOT EXISTS forms (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        is_locked BOOLEAN DEFAULT false,
        created_by INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT NOW()
      )
    `);

        // Form versions table
        await client.query(`
      CREATE TABLE IF NOT EXISTS form_versions (
        id SERIAL PRIMARY KEY,
        form_id INTEGER NOT NULL REFERENCES forms(id) ON DELETE CASCADE,
        version_number INTEGER NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT NOW()
      )
    `);

        // Form fields table
        await client.query(`
      CREATE TABLE IF NOT EXISTS form_fields (
        id SERIAL PRIMARY KEY,
        form_version_id INTEGER NOT NULL REFERENCES form_versions(id) ON DELETE CASCADE,
        label TEXT NOT NULL,
        type TEXT NOT NULL,
        options_json JSONB DEFAULT '{}',
        field_order INTEGER NOT NULL DEFAULT 0,
        required BOOLEAN DEFAULT false
      )
    `);

        // Submissions table
        await client.query(`
      CREATE TABLE IF NOT EXISTS submissions (
        id SERIAL PRIMARY KEY,
        form_version_id INTEGER NOT NULL REFERENCES form_versions(id) ON DELETE CASCADE,
        submitted_by INTEGER REFERENCES users(id),
        submitted_at TIMESTAMP DEFAULT NOW()
      )
    `);

        // Submission values table
        await client.query(`
      CREATE TABLE IF NOT EXISTS submission_values (
        id SERIAL PRIMARY KEY,
        submission_id INTEGER NOT NULL REFERENCES submissions(id) ON DELETE CASCADE,
        field_id INTEGER NOT NULL REFERENCES form_fields(id) ON DELETE CASCADE,
        value TEXT
      )
    `);

        // Pincodes table
        await client.query(`
      CREATE TABLE IF NOT EXISTS pincodes (
        pincode VARCHAR(10) PRIMARY KEY,
        district TEXT,
        state TEXT
      )
    `);

        // Colleges table
        await client.query(`
      CREATE TABLE IF NOT EXISTS colleges (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        state TEXT,
        district TEXT
      )
    `);

        // Indexes
        await client.query('CREATE INDEX IF NOT EXISTS idx_pincodes_pincode ON pincodes (pincode)');
        await client.query('CREATE INDEX IF NOT EXISTS idx_colleges_name_trgm ON colleges USING gin (name gin_trgm_ops)');
        await client.query('CREATE INDEX IF NOT EXISTS idx_form_versions_form_id ON form_versions (form_id)');
        await client.query('CREATE INDEX IF NOT EXISTS idx_form_fields_version_id ON form_fields (form_version_id)');
        await client.query('CREATE INDEX IF NOT EXISTS idx_submissions_version_id ON submissions (form_version_id)');
        await client.query('CREATE INDEX IF NOT EXISTS idx_submission_values_submission_id ON submission_values (submission_id)');

        await client.query('COMMIT');
        console.log('✅ Migration completed successfully');
    } catch (err) {
        await client.query('ROLLBACK');
        console.error('❌ Migration failed:', err.message);
        throw err;
    } finally {
        client.release();
        await pool.end();
    }
}

migrate();
