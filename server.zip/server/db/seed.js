const pool = require('./pool');
const fs = require('fs');
const path = require('path');
const csvParser = require('csv-parser');

async function seedPincodes(client) {
    const csvPath = path.join(__dirname, '..', 'data', 'pincodes.csv');

    if (fs.existsSync(csvPath)) {
        console.log('📦 Seeding pincodes from CSV...');
        const rows = [];
        await new Promise((resolve, reject) => {
            fs.createReadStream(csvPath)
                .pipe(csvParser())
                .on('data', (row) => {
                    // Expecting columns: pincode, district, state (case-insensitive)
                    const pincode = row.pincode || row.Pincode || row.PINCODE;
                    const district = row.district || row.District || row.DISTRICT;
                    const state = row.state || row.State || row.STATE;
                    if (pincode) rows.push({ pincode: pincode.toString().trim(), district: (district || '').trim(), state: (state || '').trim() });
                })
                .on('end', resolve)
                .on('error', reject);
        });

        // Batch insert
        const batchSize = 500;
        for (let i = 0; i < rows.length; i += batchSize) {
            const batch = rows.slice(i, i + batchSize);
            const values = [];
            const placeholders = batch.map((r, idx) => {
                const base = idx * 3;
                values.push(r.pincode, r.district, r.state);
                return `($${base + 1}, $${base + 2}, $${base + 3})`;
            }).join(', ');

            await client.query(
                `INSERT INTO pincodes (pincode, district, state) VALUES ${placeholders} ON CONFLICT (pincode) DO NOTHING`,
                values
            );
        }
        console.log(`  ✅ Inserted ${rows.length} pincodes`);
    } else {
        console.log('📦 Seeding sample pincodes (no CSV found)...');
        const samplePincodes = [
            ['110001', 'New Delhi', 'Delhi'],
            ['110002', 'New Delhi', 'Delhi'],
            ['110003', 'New Delhi', 'Delhi'],
            ['400001', 'Mumbai', 'Maharashtra'],
            ['400002', 'Mumbai', 'Maharashtra'],
            ['400003', 'Mumbai', 'Maharashtra'],
            ['500001', 'Hyderabad', 'Telangana'],
            ['500002', 'Hyderabad', 'Telangana'],
            ['600001', 'Chennai', 'Tamil Nadu'],
            ['600002', 'Chennai', 'Tamil Nadu'],
            ['700001', 'Kolkata', 'West Bengal'],
            ['700002', 'Kolkata', 'West Bengal'],
            ['560001', 'Bangalore', 'Karnataka'],
            ['560002', 'Bangalore', 'Karnataka'],
            ['380001', 'Ahmedabad', 'Gujarat'],
            ['411001', 'Pune', 'Maharashtra'],
            ['302001', 'Jaipur', 'Rajasthan'],
            ['226001', 'Lucknow', 'Uttar Pradesh'],
            ['160001', 'Chandigarh', 'Chandigarh'],
            ['201001', 'Ghaziabad', 'Uttar Pradesh'],
        ];
        for (const [pincode, district, state] of samplePincodes) {
            await client.query(
                'INSERT INTO pincodes (pincode, district, state) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING',
                [pincode, district, state]
            );
        }
        console.log('  ✅ Inserted 20 sample pincodes');
    }
}

async function seedColleges(client) {
    const csvPath = path.join(__dirname, '..', 'data', 'colleges.csv');

    if (fs.existsSync(csvPath)) {
        console.log('📦 Seeding colleges from CSV...');
        const rows = [];
        await new Promise((resolve, reject) => {
            fs.createReadStream(csvPath)
                .pipe(csvParser())
                .on('data', (row) => {
                    const name = row.name || row.Name || row.NAME || row['College Name'] || row['college_name'];
                    const state = row.state || row.State || row.STATE;
                    const district = row.district || row.District || row.DISTRICT;
                    if (name) rows.push({ name: name.trim(), state: (state || '').trim(), district: (district || '').trim() });
                })
                .on('end', resolve)
                .on('error', reject);
        });

        const batchSize = 500;
        for (let i = 0; i < rows.length; i += batchSize) {
            const batch = rows.slice(i, i + batchSize);
            const values = [];
            const placeholders = batch.map((r, idx) => {
                const base = idx * 3;
                values.push(r.name, r.state, r.district);
                return `($${base + 1}, $${base + 2}, $${base + 3})`;
            }).join(', ');

            await client.query(
                `INSERT INTO colleges (name, state, district) VALUES ${placeholders}`,
                values
            );
        }
        console.log(`  ✅ Inserted ${rows.length} colleges`);
    } else {
        console.log('📦 Seeding sample colleges (no CSV found)...');
        const sampleColleges = [
            ['Indian Institute of Technology Delhi', 'Delhi', 'New Delhi'],
            ['Indian Institute of Technology Bombay', 'Maharashtra', 'Mumbai'],
            ['Indian Institute of Technology Madras', 'Tamil Nadu', 'Chennai'],
            ['Indian Institute of Technology Kanpur', 'Uttar Pradesh', 'Kanpur'],
            ['Indian Institute of Technology Kharagpur', 'West Bengal', 'Paschim Medinipur'],
            ['Indian Institute of Science', 'Karnataka', 'Bangalore'],
            ['Jawaharlal Nehru University', 'Delhi', 'New Delhi'],
            ['University of Delhi', 'Delhi', 'New Delhi'],
            ['Banaras Hindu University', 'Uttar Pradesh', 'Varanasi'],
            ['Anna University', 'Tamil Nadu', 'Chennai'],
            ['University of Hyderabad', 'Telangana', 'Hyderabad'],
            ['Jadavpur University', 'West Bengal', 'Kolkata'],
            ['Savitribai Phule Pune University', 'Maharashtra', 'Pune'],
            ['University of Mumbai', 'Maharashtra', 'Mumbai'],
            ['Osmania University', 'Telangana', 'Hyderabad'],
            ['Gujarat University', 'Gujarat', 'Ahmedabad'],
            ['University of Rajasthan', 'Rajasthan', 'Jaipur'],
            ['Lucknow University', 'Uttar Pradesh', 'Lucknow'],
            ['Panjab University', 'Chandigarh', 'Chandigarh'],
            ['Aligarh Muslim University', 'Uttar Pradesh', 'Aligarh'],
        ];
        for (const [name, state, district] of sampleColleges) {
            await client.query(
                'INSERT INTO colleges (name, state, district) VALUES ($1, $2, $3)',
                [name, state, district]
            );
        }
        console.log('  ✅ Inserted 20 sample colleges');
    }
}

async function seed() {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        await seedPincodes(client);
        await seedColleges(client);
        await client.query('COMMIT');
        console.log('✅ Seeding completed');
    } catch (err) {
        await client.query('ROLLBACK');
        console.error('❌ Seeding failed:', err.message);
        throw err;
    } finally {
        client.release();
        await pool.end();
    }
}

seed();
